package ca.sheridancollege.kachhidh.bootstrap;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import ca.sheridancollege.kachhidh.beans.Podcast;

import ca.sheridancollege.kachhidh.beans.StreamService;
import ca.sheridancollege.kachhidh.repositories.PodcastRepository;

import ca.sheridancollege.kachhidh.repositories.StreamServiceRepository;
import lombok.AllArgsConstructor;

@AllArgsConstructor     
@Component
public class BootstrapData implements CommandLineRunner {

	private PodcastRepository podcastRepository;
	private StreamServiceRepository streamServiceRepository;
	

	@Override
	public void run(String... args) throws Exception {
		
		StreamService service1 = StreamService.builder()
	            .name("Spotify")
	            .link("https://www.spotify.com")
				.description("Spotify Podcast includes Podcasts, Best Episodes, Editor's Picks and many more")
	            .build();
	       
	        StreamService service2 = StreamService.builder()
	            .name("Apple Podcasts")
	            .link("https://www.apple.com/apple-podcasts")
				.description("Most Premium Podcast in this industry")				
	            .build();
	        
	        StreamService service3 = StreamService.builder()
	            .name("Google Podcasts")
	            .link("https://podcasts.google.com")
				.description("Google Podcast is free and simple website tolisten podcasts of your choice")				
	            .build();
	        
	        StreamService service4 = StreamService.builder()
		            .name("Dhairya Podcasts")
		            .link("https://www.youtube.com/hashtag/podcasts")
					.description("This is my personal podcast list")				
		            .build();
	        
	       streamServiceRepository.save(service1); 
	       streamServiceRepository.save(service2);
	        streamServiceRepository.save(service3);
	        streamServiceRepository.save(service4);
		
		Podcast podcast1 = Podcast.builder()
	            .title("Reply All")
	            .description("A podcast about the internet.")
	            .years(2012)
	            .rating(4.5)
	            .link("https://gimletmedia.com/shows/reply-all")
	            .service(service1)
	            .build();
	      

	        Podcast podcast2 = Podcast.builder()
	            .title("Stuff You Should Know")
	            .description("A science and history podcast to culture and society.")
	            .years(2020)
	            .rating(3.9)
	            .link("https://www.iheart.com/podcast/105-stuff-you-should-know-26940277/")  
	            .service(service2)
	            .build();
	        

	        Podcast podcast3 = Podcast.builder()
	            .title("How I Built This")
	            .description("A podcast about entrepreneurs and their businesses")
	            .years(2016)
	            .rating(4.3)
	            .link("https://www.npr.org/podcasts/510313/how-i-built-this")
	            .service(service3)
	            .build();
	        

	        Podcast podcast4 = Podcast.builder()
	            .title("Radiolab")
	            .description("A show that investigates the mysteries of the world.")
	            .years(2022)
	            .rating(4.9)
	            .link("https://www.wnycstudios.org/podcasts/radiolab")
	            .service(service2)
	            .build();
	        

	        Podcast podcast5 = Podcast.builder()
	            .title("The Daily")
	            .description("A news podcast from The New York Times that covers the most important stories of the day.")
	            .years(2023)
	            .rating(4.0)
	            .link("https://www.nytimes.com/column/the-daily")
	            .service(service1)
	            .build();
	        podcastRepository.save(podcast1);
	        podcastRepository.save(podcast2);
	        podcastRepository.save(podcast3);
	        podcastRepository.save(podcast4);
	        podcastRepository.save(podcast5);
	        
		

	        
	}

}
