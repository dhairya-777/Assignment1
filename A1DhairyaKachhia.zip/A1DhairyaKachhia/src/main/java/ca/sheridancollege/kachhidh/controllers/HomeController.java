package ca.sheridancollege.kachhidh.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import ca.sheridancollege.kachhidh.beans.Podcast;
import ca.sheridancollege.kachhidh.beans.StreamService;
import ca.sheridancollege.kachhidh.repositories.PodcastRepository;
import ca.sheridancollege.kachhidh.repositories.StreamServiceRepository;
import lombok.AllArgsConstructor;

@Controller	
@AllArgsConstructor
public class HomeController {

	private PodcastRepository podcastRepository;
	private StreamServiceRepository streamServiceRepository;
	
	@GetMapping("/")
	public String loadindex(Model model) {
		model.addAttribute("podcast", new Podcast());
		model.addAttribute("podcastlist", podcastRepository.findAll());
		//model.addAttribute("podcastlist", podcastRepository.findByservice_IdIsNotNull());
		return "index";
	}
	@GetMapping("/viewStream")
	public String loadviewStream(Model model) {
		model.addAttribute("stream", new StreamService());
		model.addAttribute("streamList", streamServiceRepository.findAll());
		return "viewStream";
	}
	
	@GetMapping("/orderByTitle")
	public String orderByTitle(Model model) {
		model.addAttribute("podcastlist", podcastRepository.findByOrderByTitle());
		return "index";
	}
	
	@GetMapping("/orderByDescription")
	public String orderByDesc(Model model) {
		model.addAttribute("podcastlist", podcastRepository.findByOrderByDescription());
		return "index";
	}
	
	@GetMapping("/orderByYear")
	public String orderByYear(Model model) {
		model.addAttribute("podcastlist", podcastRepository.findByOrderByYears());
		return "index";
	}
	
	@GetMapping("/orderByRating")
	public String orderByRating(Model model) {
		model.addAttribute("podcastlist", podcastRepository.findByOrderByRating());
		return "index";
	}
	
	@GetMapping("/addStream")
	public String gotoStream(Model model) {
		model.addAttribute("stream", new StreamService());
		model.addAttribute("podcastList", podcastRepository.findAll());
		model.addAttribute("services", streamServiceRepository.findAll());
		return "addStream";
	}
	@PostMapping("/addStream")
	public String addNewStream(Model model, @ModelAttribute StreamService serv) {
		model.addAttribute("stream", new StreamService());
		model.addAttribute("podcastList", podcastRepository.findAll());
		model.addAttribute("services", streamServiceRepository.findAll());
		streamServiceRepository.save(serv);
		return "redirect:/viewStream";
	}
	
	@GetMapping("/editStream/{id}")
	public String editStream(@PathVariable Long id, Model model) {
		Optional<StreamService> serv = streamServiceRepository.findById(id);
		
		if(serv.isPresent()) {
			model.addAttribute("stream", serv.get());
			return "editStream.html";
		}
		else {
			return "redirect:/viewStream";
		}
	}
	@PostMapping("/editStream")
	public String editStreamServ(@ModelAttribute StreamService serv, Model model) {
		streamServiceRepository.save(serv);
		return "redirect:/viewStream";
	}
	
	@GetMapping("/deleteStream/{id}")
	public String deleteStreambyId(@PathVariable Long id) {
		Optional<StreamService> serv = streamServiceRepository.findById(id);
		if(serv.isPresent()) {
			streamServiceRepository.deleteById(id);
		}
		return "redirect:/viewStream";
	}
	
	@GetMapping("/addPodcast")
	public String addPodcast(Model model) {
		model.addAttribute("podcast", new Podcast());
		model.addAttribute("podcastList", podcastRepository.findAll());
		model.addAttribute("services", streamServiceRepository.findAll());
		return "addPodcast";
	}
	@PostMapping("/addPodcast")
	public String addNew(Model model, @ModelAttribute Podcast podcast) {
		model.addAttribute("podcast", new Podcast());
		model.addAttribute("podcastList", podcastRepository.findAll());
		model.addAttribute("services", streamServiceRepository.findAll());
		podcastRepository.save(podcast);
		return "redirect:/";
	}
	
	@GetMapping("/edit/{id}")
	public String editPodcast(@PathVariable Long id, Model model) {
		Optional<Podcast> pod = podcastRepository.findById(id);
		
		if(pod.isPresent()) {
			model.addAttribute("podcast", pod.get());
			model.addAttribute("services", streamServiceRepository.findAll());
			return "editPodcast.html";
		}
		else {
			return "redirect:/";
		}
	}
	@PostMapping("/edit")
	public String edit(@ModelAttribute Podcast podcast, Model model) {
		podcastRepository.save(podcast);
		return "redirect:/";
	}
	
	@GetMapping("/delete/{id}")
	public String deleteRecord(@PathVariable Long id) {
		Optional<Podcast> pod = podcastRepository.findById(id);
		if(pod.isPresent()) {
			podcastRepository.deleteById(id);
		}
		return "redirect:/";
	}
}
