package ca.sheridancollege.kachhidh.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ca.sheridancollege.kachhidh.beans.Podcast;

public interface PodcastRepository extends JpaRepository<Podcast, Long> {

	public List<Podcast> findByservice_IdIsNotNull();
	
	public List<Podcast> findByOrderByTitle();
	public List<Podcast> findByOrderByYears();
	public List<Podcast> findByOrderByDescription();
	public List<Podcast> findByOrderByRating();
	public List<Podcast> findByOrderByService();
}
