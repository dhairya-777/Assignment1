package ca.sheridancollege.kachhidh.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ca.sheridancollege.kachhidh.beans.Podcast;
import ca.sheridancollege.kachhidh.beans.StreamService;

public interface StreamServiceRepository extends JpaRepository<StreamService, Long> {

//  public List<StreamService> findByPodcast_IdIsNotNull();	
	//StreamService findByName(String name);
	
	//public List<StreamService> findByName();
}
